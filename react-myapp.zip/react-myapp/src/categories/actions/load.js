import axios from 'axios';

function load(){
    return function(dispatch){
        axios
            .get('http://localhost:3030/categories')
            .then(response => response.data)
            .then(function(categoryList){
                const action = { type: "INIT_CATEGORIES", payload: categoryList };
                dispatch(action);
            });
    }
}

export default load;